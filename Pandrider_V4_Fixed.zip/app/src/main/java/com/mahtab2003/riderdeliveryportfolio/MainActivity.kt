package com.mahtab2003.riderdeliveryportfolio

import android.content.Context
import android.graphics.Paint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

// Offline demo data. This is original Pandrider demo UI; it is not connected to Foodpanda servers.
data class OrderItem(var name:String,var option:String,var qty:Int,var price:Double)
data class RiderState(
    var riderName:String="Demo Rider", var riderId:String="PR-10001", var zone:String="Lahore",
    var referralUrl:String="https://example.com/ref/demo", var restaurant:String="Demo Restaurant", var orderNo:String="#PDR-1001",
    var customerName:String="Demo Customer", var customerCode:String="C-1001", var customerPhone:String="0300-0000000",
    var pickupAddress:String="Main Boulevard, Lahore", var pickupStreet:String="Main Boulevard", var pickupCity:String="Lahore",
    var dropoffAddress:String="Model Town, Lahore", var dropoffStreet:String="Model Town Link Road", var dropoffCity:String="Lahore",
    var deliveryNote:String="Please call on arrival", var arrivalMinutes:String="8", var paymentMethod:String="Cash", var cashAmount:String="1200",
    var wallet:String="2500", var maxWallet:String="10000", var stage:String="Pickup", var vendorDistance:String="Near",
    var customerDistance:String="Far", var photoRequired:Boolean=true, var licenseExpiry:String="31/12/2027",
    var idCardNumber:String="DEMO-ID-0001", var idCardExpiry:String="31/12/2029", var restaurantPhoto:String="No photo selected",
    var customerPhoto:String="No photo selected", var licensePhoto:String="No photo selected", var idCardPhoto:String="No photo selected",
    var orderStatus:String="Assigned", var items:List<OrderItem> = listOf(
        OrderItem("Chicken Biryani","Regular",1,450.0), OrderItem("Coke 345ml","Bottle",1,120.0)
    )
) {
    fun json():String {
        val o=JSONObject()
        o.put("riderName",riderName);o.put("riderId",riderId);o.put("zone",zone);o.put("referralUrl",referralUrl)
        o.put("restaurant",restaurant);o.put("orderNo",orderNo);o.put("customerName",customerName);o.put("customerCode",customerCode);o.put("customerPhone",customerPhone)
        o.put("pickupAddress",pickupAddress);o.put("pickupStreet",pickupStreet);o.put("pickupCity",pickupCity)
        o.put("dropoffAddress",dropoffAddress);o.put("dropoffStreet",dropoffStreet);o.put("dropoffCity",dropoffCity)
        o.put("deliveryNote",deliveryNote);o.put("arrivalMinutes",arrivalMinutes);o.put("paymentMethod",paymentMethod);o.put("cashAmount",cashAmount)
        o.put("wallet",wallet);o.put("maxWallet",maxWallet);o.put("stage",stage);o.put("vendorDistance",vendorDistance);o.put("customerDistance",customerDistance)
        o.put("photoRequired",photoRequired);o.put("licenseExpiry",licenseExpiry);o.put("idCardNumber",idCardNumber);o.put("idCardExpiry",idCardExpiry)
        o.put("restaurantPhoto",restaurantPhoto);o.put("customerPhoto",customerPhoto);o.put("licensePhoto",licensePhoto);o.put("idCardPhoto",idCardPhoto);o.put("orderStatus",orderStatus)
        val a=JSONArray();items.forEach{i->a.put(JSONObject().apply{put("name",i.name);put("option",i.option);put("qty",i.qty);put("price",i.price)})};o.put("items",a)
        return o.toString()
    }
    companion object {
        fun from(s:String):RiderState=try{
            val o=JSONObject(s);val a=o.optJSONArray("items")?:JSONArray();val l=mutableListOf<OrderItem>()
            for(n in 0 until a.length()){val x=a.getJSONObject(n);l.add(OrderItem(x.optString("name"),x.optString("option"),x.optInt("qty",1),x.optDouble("price")))}
            RiderState(
                o.optString("riderName","Demo Rider"),o.optString("riderId","PR-10001"),o.optString("zone","Lahore"),o.optString("referralUrl","https://example.com/ref/demo"),
                o.optString("restaurant","Demo Restaurant"),o.optString("orderNo","#PDR-1001"),o.optString("customerName","Demo Customer"),o.optString("customerCode","C-1001"),o.optString("customerPhone","0300-0000000"),
                o.optString("pickupAddress","Main Boulevard, Lahore"),o.optString("pickupStreet","Main Boulevard"),o.optString("pickupCity","Lahore"),
                o.optString("dropoffAddress","Model Town, Lahore"),o.optString("dropoffStreet","Model Town Link Road"),o.optString("dropoffCity","Lahore"),
                o.optString("deliveryNote","Please call on arrival"),o.optString("arrivalMinutes","8"),o.optString("paymentMethod","Cash"),o.optString("cashAmount","1200"),
                o.optString("wallet","2500"),o.optString("maxWallet","10000"),o.optString("stage","Pickup"),o.optString("vendorDistance","Near"),o.optString("customerDistance","Far"),o.optBoolean("photoRequired",true),
                o.optString("licenseExpiry","31/12/2027"),o.optString("idCardNumber","DEMO-ID-0001"),o.optString("idCardExpiry","31/12/2029"),
                o.optString("restaurantPhoto","No photo selected"),o.optString("customerPhoto","No photo selected"),o.optString("licensePhoto","No photo selected"),o.optString("idCardPhoto","No photo selected"),o.optString("orderStatus","Assigned"),l)
        }catch(_:Exception){RiderState()}
    }
}

class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{PandriderApp(applicationContext)}}}

@Composable fun Logo(modifier:Modifier=Modifier){Row(modifier,verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(52.dp).background(MaterialTheme.colorScheme.primaryContainer,CircleShape),contentAlignment=Alignment.Center){Text("P",fontSize=30.sp,fontWeight=FontWeight.ExtraBold,color=MaterialTheme.colorScheme.primary)};Spacer(Modifier.width(10.dp));Column{Text("Pandrider",fontSize=25.sp,fontWeight=FontWeight.ExtraBold);Text("Rider Delivery",fontSize=11.sp)}}}

@Composable fun LoginScreen(ctx:Context,onLogin:()->Unit){val p=ctx.getSharedPreferences("pandrider_auth",0);var user by remember{mutableStateOf(p.getString("user","rider")?:"rider")};var pass by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Logo();Spacer(Modifier.height(35.dp));Text("Rider Login",fontSize=25.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(18.dp));OutlinedTextField(user,{user=it},label={Text("Username")},singleLine=true,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(10.dp));OutlinedTextField(pass,{pass=it},label={Text("Password / Key")},singleLine=true,visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth());if(error.isNotEmpty())Text(error,color=MaterialTheme.colorScheme.error,modifier=Modifier.padding(8.dp));Spacer(Modifier.height(15.dp));Button(onClick={val saved=p.getString("pass",null);val savedUser=p.getString("user","rider")?:"rider";val ok=if(saved==null){user=="rider"&&pass=="1234"}else user==savedUser&&pass==saved;if(ok){p.edit().putString("user",user).apply();onLogin()}else error="Wrong username or password/key"},modifier=Modifier.fillMaxWidth()){Text("LOGIN")};Spacer(Modifier.height(10.dp));Text("First demo login: rider / 1234",fontSize=12.sp)}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun PandriderApp(ctx:Context){val auth=ctx.getSharedPreferences("pandrider_auth",0);var logged by remember{mutableStateOf(auth.getBoolean("logged",false))};if(!logged){LoginScreen(ctx){auth.edit().putBoolean("logged",true).apply();logged=true};return};val prefs=ctx.getSharedPreferences("pandrider_demo",0);var state by remember{mutableStateOf(prefs.getString("state",null)?.let(RiderState::from)?:RiderState())};var screen by remember{mutableStateOf("home")};var online by remember{mutableStateOf(true)};var drawer by remember{mutableStateOf(false)};var mock by remember{mutableStateOf(false)};var taps by remember{mutableIntStateOf(0)};fun save(s:RiderState){state=s;prefs.edit().putString("state",s.json()).apply()}
    MaterialTheme{ModalNavigationDrawer(drawerState=rememberDrawerState(if(drawer)DrawerValue.Open else DrawerValue.Closed),drawerContent={ModalDrawerSheet{Spacer(Modifier.height(20.dp));Logo(Modifier.padding(20.dp));listOf("home" to "Home","order" to "Orders","schedule" to "Schedule","wallet" to "Wallet","payments" to "Payments","profile" to "My Profile","resources" to "Resources","settings" to "Settings").forEach{(id,label)->NavigationDrawerItem(label={Text(label)},selected=screen==id,onClick={screen=id;drawer=false},icon={Icon(Icons.Default.Circle,null)},modifier=Modifier.padding(horizontal=12.dp))};HorizontalDivider(Modifier.padding(vertical=8.dp));NavigationDrawerItem(label={Text("Logout")},selected=false,onClick={auth.edit().putBoolean("logged",false).apply();logged=false;drawer=false},icon={Icon(Icons.Default.Logout,null)},modifier=Modifier.padding(horizontal=12.dp))}},content={Scaffold(topBar={TopAppBar(navigationIcon={IconButton({drawer=true}){Icon(Icons.Default.Menu,"Menu")}},title={Box(Modifier.clickable{taps++;if(taps>=7){mock=true;taps=0}}){Logo()}},actions={AssistChip(onClick={online=!online},label={Text(if(online)"ONLINE" else "OFFLINE")})})},bottomBar={NavigationBar{NavigationBarItem(screen=="home",{screen="home"},{Icon(Icons.Default.Home,null)},label={Text("Home")});NavigationBarItem(screen=="order",{screen="order"},{Icon(Icons.Default.List,null)},label={Text("Order")});NavigationBarItem(screen=="wallet",{screen="wallet"},{Icon(Icons.Default.AccountBalanceWallet,null)},label={Text("Wallet")});NavigationBarItem(screen=="profile",{screen="profile"},{Icon(Icons.Default.Person,null)},label={Text("Profile")})}}){pad->when(screen){"order"->OrderScreen(state,{save(it)},Modifier.padding(pad));"wallet","payments"->WalletScreen(state,Modifier.padding(pad));"profile","settings"->ProfileScreen(state,Modifier.padding(pad));"schedule"->Simple("Schedule","No scheduled orders in offline demo.",Modifier.padding(pad));"resources"->Simple("Resources","Help, FAQs and rider resources.",Modifier.padding(pad));else->HomeScreen(state,online,{save(it)},Modifier.padding(pad))}}});if(mock)MockSettings(state,{mock=false},{save(it);mock=false},ctx)}}}

@Composable fun HomeScreen(s:RiderState,online:Boolean,update:(RiderState)->Unit,m:Modifier){LazyColumn(m.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Card(Modifier.fillMaxWidth(),RoundedCornerShape(22.dp)){Column(Modifier.padding(18.dp)){Text("Good day, ${s.riderName}",fontSize=22.sp,fontWeight=FontWeight.Bold);Text("${s.riderId} • ${s.zone}");Spacer(Modifier.height(8.dp));Text(if(online)"You are online and ready for orders." else "You are offline.")}}};item{Text("Live Area Map",fontSize=20.sp,fontWeight=FontWeight.Bold)};item{OfflineAreaMap(s)};item{Text("Current Order",fontSize=20.sp,fontWeight=FontWeight.Bold)};item{Card(Modifier.fillMaxWidth(),RoundedCornerShape(20.dp)){Column(Modifier.padding(18.dp)){Text(s.restaurant,fontSize=19.sp,fontWeight=FontWeight.Bold);Text(s.orderNo);Text("Pickup • ${s.pickupAddress}");Text("Drop-off • ${s.dropoffAddress}");Text("Customer • ${s.customerName} (${s.customerCode})");Text("Stage: ${s.stage}");Spacer(Modifier.height(10.dp));Button(onClick={update(s.copy(stage="Pickup",orderStatus="Picked up"))},Modifier.fillMaxWidth()){Text("Confirm Pickup")}}}};item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Info("Wallet","Rs ${s.wallet}",Modifier.weight(1f));Info("Cash","Rs ${s.cashAmount}",Modifier.weight(1f))}}}}

@Composable fun OfflineAreaMap(s:RiderState){var pan by remember{mutableStateOf(Offset.Zero)};var zoom by remember{mutableFloatStateOf(1f)};val transition=rememberInfiniteTransition(label="rider");val pulse by transition.animateFloat(initialValue=0f,targetValue=1f,animationSpec=infiniteRepeatable(tween(1100,easing=LinearEasing),RepeatMode.Reverse),label="pulse");Card(Modifier.fillMaxWidth().height(300.dp),RoundedCornerShape(20.dp)){Box(Modifier.fillMaxSize().background(Color(0xFFE9E7DF)).pointerInput(Unit){detectDragGestures{change,dragAmount->change.consume();pan=pan+dragAmount}}){Canvas(Modifier.fillMaxSize()){val w=size.width;val h=size.height;val sx=zoom;fun pt(x:Float,y:Float)=Offset(w/2+(x-w/2)*sx+pan.x,h/2+(y-h/2)*sx+pan.y);val road=Color(0xFFF9F8F3);val major=Color(0xFFFFFFFF);val line=Color(0xFFC6C3BA);for(i in 0..8){val y=h*(i+1)/10f;drawLine(line,pt(0f,y),pt(w,y),2f)};for(i in 0..7){val x=w*(i+1)/9f;drawLine(line,pt(x,0f),pt(x,h),2f)};drawLine(major,pt(0f,h*.32f),pt(w,h*.55f),12f);drawLine(major,pt(w*.1f,h*.82f),pt(w*.9f,h*.15f),10f);drawLine(road,pt(0f,h*.32f),pt(w,h*.55f),7f);drawLine(road,pt(w*.1f,h*.82f),pt(w*.9f,h*.15f),6f);val rider=pt(w*.42f,h*.52f);val customer=pt(w*.67f,h*.42f);drawCircle(Color(0xFF3F51B5),18f,rider);drawCircle(Color.White,7f,rider);drawCircle(Color(0xFFFF5252),20f+8f*pulse,customer,style=Stroke(width=3f));drawCircle(Color(0xFFFF5252),9f,customer);val paint=Paint().apply{color=android.graphics.Color.DKGRAY;textSize=28f;isAntiAlias=true;typeface=android.graphics.Typeface.DEFAULT_BOLD};fun label(t:String,p:Offset){drawContext.canvas.nativeCanvas.drawText(t,p.x,p.y,paint)};label("DHA",pt(w*.13f,h*.22f));label("Gulberg",pt(w*.48f,h*.17f));label("Model Town",pt(w*.17f,h*.72f));label("Johar Town",pt(w*.60f,h*.73f));label("Liberty",pt(w*.48f,h*.39f));label("MM Alam",pt(w*.52f,h*.53f));label("Hotel",pt(w*.78f,h*.24f));label("Packages Mall",pt(w*.04f,h*.50f))};Column(Modifier.align(Alignment.TopEnd).padding(8.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){SmallMapButton("+"){zoom=min(1.8f,zoom+.15f)};SmallMapButton("−"){zoom=max(.7f,zoom-.15f)};SmallMapButton("↺"){pan=Offset.Zero;zoom=1f}};Row(Modifier.align(Alignment.BottomStart).padding(10.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(20.dp).background(Color(0xFF3F51B5),CircleShape));Spacer(Modifier.width(6.dp));Text("Rider") ;Spacer(Modifier.width(14.dp));Box(Modifier.size(20.dp).background(Color(0xFFFF5252),CircleShape));Spacer(Modifier.width(6.dp));Text("Customer")}}}
@Composable fun SmallMapButton(t:String,onClick:()->Unit){Surface(onClick=onClick,shape=RoundedCornerShape(8.dp),shadowElevation=3.dp){Box(Modifier.size(38.dp),contentAlignment=Alignment.Center){Text(t,fontSize=20.sp,fontWeight=FontWeight.Bold)}}}

@Composable fun Info(a:String,b:String,m:Modifier)=Card(m){Column(Modifier.padding(15.dp)){Text(a);Text(b,fontWeight=FontWeight.Bold,fontSize=18.sp)}}

@Composable fun OrderScreen(s:RiderState,update:(RiderState)->Unit,m:Modifier){LazyColumn(m.padding(16.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){item{Text("Order ${s.orderNo}",fontSize=24.sp,fontWeight=FontWeight.Bold)};item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(s.restaurant,fontSize=19.sp,fontWeight=FontWeight.Bold);Text("Customer: ${s.customerName}");Text("Code: ${s.customerCode} • Phone: ${s.customerPhone}");Text("Payment: ${s.paymentMethod} • Rs ${s.cashAmount}");Text("Pickup: ${s.pickupAddress}");Text("Drop-off: ${s.dropoffAddress}");Text("Arrival: ${s.arrivalMinutes} min");Text("Note: ${s.deliveryNote}")}}};item{Text("Order Items",fontSize=20.sp,fontWeight=FontWeight.Bold)};itemsIndexed(s.items){i,x->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(x.name,fontWeight=FontWeight.Bold);Text("${x.option} • Qty ${x.qty} • Rs ${x.price}")};IconButton({val l=s.items.toMutableList();l.removeAt(i);update(s.copy(items=l))}){Icon(Icons.Default.Delete,"Delete")}};Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){TextButton({val l=s.items.toMutableList();l[i]=x.copy(qty=x.qty+1);update(s.copy(items=l))}){Text("+ Qty")};TextButton({val l=s.items.toMutableList();l[i]=x.copy(qty=max(1,x.qty-1));update(s.copy(items=l))}){Text("− Qty")}}}}};item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton({update(s.copy(stage="Pickup",orderStatus="At pickup"))},Modifier.weight(1f)){Text("Pickup")};Button({update(s.copy(stage="Drop-off",orderStatus="Out for delivery"))},Modifier.weight(1f)){Text("Drop-off")}}};item{Button({update(s.copy(items=s.items+OrderItem("New Item","Regular",1,100.0)))},Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Spacer(Modifier.width(6.dp));Text("Add Item")}}}}

@Composable fun WalletScreen(s:RiderState,m:Modifier)=Column(m.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Wallet & Payments",fontSize=24.sp,fontWeight=FontWeight.Bold);Info("Wallet Balance","Rs ${s.wallet}",Modifier.fillMaxWidth());Info("Maximum Limit","Rs ${s.maxWallet}",Modifier.fillMaxWidth());Info("Current Cash","Rs ${s.cashAmount}",Modifier.fillMaxWidth())}
@Composable fun ProfileScreen(s:RiderState,m:Modifier)=LazyColumn(m.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("My Profile",fontSize=24.sp,fontWeight=FontWeight.Bold)};item{Text("Name: ${s.riderName}")};item{Text("Rider ID: ${s.riderId}")};item{Text("Zone: ${s.zone}")};item{Text("Referral URL: ${s.referralUrl}")};item{Text("License Expiry: ${s.licenseExpiry}")};item{Text("ID Card: ${s.idCardNumber}")};item{Text("Order Status: ${s.orderStatus}")};item{Text("App Version: 4.0.0")};item{Text("Hidden Mock Settings: tap the Pandrider title 7 times.")}}
@Composable fun Simple(t:String,b:String,m:Modifier)=Column(m.padding(20.dp)){Text(t,fontSize=24.sp,fontWeight=FontWeight.Bold);Text(b)}

@Composable fun MockSettings(s0:RiderState,close:()->Unit,save:(RiderState)->Unit,ctx:Context){var s by remember{mutableStateOf(s0)};val auth=ctx.getSharedPreferences("pandrider_auth",0);var newUser by remember{mutableStateOf(auth.getString("user","rider")?:"rider")};var newPass by remember{mutableStateOf("")};AlertDialog(onDismissRequest=close,title={Text("Hidden Mock Settings • V4")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(7.dp)){
    item{Text("Rider / Account",fontSize=18.sp,fontWeight=FontWeight.Bold)};item{Field("Rider Name",s.riderName){s=s.copy(riderName=it)}};item{Field("Rider ID",s.riderId){s=s.copy(riderId=it)}};item{Field("Zone",s.zone){s=s.copy(zone=it)}};item{Field("Referral URL",s.referralUrl){s=s.copy(referralUrl=it)}}
    item{Text("Order / Customer",fontSize=18.sp,fontWeight=FontWeight.Bold)};item{Field("Restaurant",s.restaurant){s=s.copy(restaurant=it)}};item{Field("Order Number",s.orderNo){s=s.copy(orderNo=it)}};item{Field("Order Status",s.orderStatus){s=s.copy(orderStatus=it)}};item{Field("Customer Name",s.customerName){s=s.copy(customerName=it)}};item{Field("Customer Code",s.customerCode){s=s.copy(customerCode=it)}};item{Field("Customer Phone",s.customerPhone){s=s.copy(customerPhone=it)}}
    item{Text("Pickup / Drop-off",fontSize=18.sp,fontWeight=FontWeight.Bold)};item{Field("Pickup Address",s.pickupAddress){s=s.copy(pickupAddress=it)}};item{Field("Pickup Street",s.pickupStreet){s=s.copy(pickupStreet=it)}};item{Field("Pickup City",s.pickupCity){s=s.copy(pickupCity=it)}};item{Field("Drop-off Address",s.dropoffAddress){s=s.copy(dropoffAddress=it)}};item{Field("Drop-off Street",s.dropoffStreet){s=s.copy(dropoffStreet=it)}};item{Field("Drop-off City",s.dropoffCity){s=s.copy(dropoffCity=it)}};item{Field("Arrival Minutes",s.arrivalMinutes){s=s.copy(arrivalMinutes=it)}};item{Field("Delivery Note",s.deliveryNote){s=s.copy(deliveryNote=it)}}
    item{Text("Payment / Wallet",fontSize=18.sp,fontWeight=FontWeight.Bold)};item{Field("Payment Method",s.paymentMethod){s=s.copy(paymentMethod=it)}};item{Field("Cash Amount",s.cashAmount){s=s.copy(cashAmount=it)}};item{Field("Wallet Balance",s.wallet){s=s.copy(wallet=it)}};item{Field("Maximum Wallet Limit",s.maxWallet){s=s.copy(maxWallet=it)}}
    item{Text("Status / Proximity",fontSize=18.sp,fontWeight=FontWeight.Bold)};item{Field("Order Stage",s.stage){s=s.copy(stage=it)}};item{Field("Vendor Proximity (Near/Far)",s.vendorDistance){s=s.copy(vendorDistance=it)}};item{Field("Customer Proximity (Near/Far)",s.customerDistance){s=s.copy(customerDistance=it)}};item{Row(verticalAlignment=Alignment.CenterVertically){Text("Drop-off Photo Required",Modifier.weight(1f));Switch(s.photoRequired,{s=s.copy(photoRequired=it)})}}
    item{Text("Documents / Photos",fontSize=18.sp,fontWeight=FontWeight.Bold)};item{Field("License Expiry",s.licenseExpiry){s=s.copy(licenseExpiry=it)}};item{Field("License Photo Reference",s.licensePhoto){s=s.copy(licensePhoto=it)}};item{Field("ID Card Number",s.idCardNumber){s=s.copy(idCardNumber=it)}};item{Field("ID Card Expiry",s.idCardExpiry){s=s.copy(idCardExpiry=it)}};item{Field("ID Card Photo Reference",s.idCardPhoto){s=s.copy(idCardPhoto=it)}};item{Field("Restaurant Photo Reference",s.restaurantPhoto){s=s.copy(restaurantPhoto=it)}};item{Field("Customer Photo Reference",s.customerPhoto){s=s.copy(customerPhoto=it)}}
    item{HorizontalDivider()};item{Text("Login Username / Key",fontSize=18.sp,fontWeight=FontWeight.Bold)};item{Field("Login Username",newUser){newUser=it}};item{OutlinedTextField(newPass,{newPass=it},label={Text("New Password / Key")},singleLine=true,visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())};item{Text("یہ صرف آف لائن ڈیمو کے لیے مقامی طور پر محفوظ ہوتا ہے۔",fontSize=12.sp)}
    item{Text("Order Items are editable from the Orders screen: add item, remove item, and change quantity.",fontSize=12.sp)}
}},confirmButton={Button(onClick={if(newUser.isNotBlank())auth.edit().putString("user",newUser).apply();if(newPass.isNotBlank())auth.edit().putString("pass",newPass).apply();save(s)}){Text("Save & Apply All Changes")}},dismissButton={Row{TextButton({save(RiderState());close()}){Text("Reset Data")};TextButton({close()}){Text("Cancel")}}})}
@Composable fun Field(label:String,v:String,c:(String)->Unit)=OutlinedTextField(v,c,label={Text(label)},singleLine=true,modifier=Modifier.fillMaxWidth())
